# Pilot Cohort Example

This is a planning example only. The user must supply lawful book sources before content analysis.

## Research question
How do enduring picture books create participation, emotional movement, and reread value with economical text?

## Possible five-book cohort

- Goodnight Moon — bedtime ritual and patterned settling
- The Very Hungry Caterpillar — concept learning, repetition, and physical/page participation
- Where the Wild Things Are — emotional fantasy and visual journey
- The Gruffalo — rhyme, repetition, escalation, and performance
- Guess How Much I Love You — reassurance and parent–child attachment

## Comparability note
These books are all picture-book read-alouds, but they serve different primary jobs. Use the cohort for broad mechanism discovery, then create narrower sub-cohorts before making strong category-specific claims.
