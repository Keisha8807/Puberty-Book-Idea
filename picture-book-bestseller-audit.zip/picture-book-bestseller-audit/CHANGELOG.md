# Changelog

## 1.0.0 — 2026-08-05

- Added cohort design for board books, picture books, and early readers.
- Added page/spread vision gate and evidence labeling.
- Added five-pillar competitive teardown framework.
- Added separate external market-evidence workflow.
- Added independent single-book audit, comparison, pattern synthesis, and implementation templates.
- Added originality and copyright boundaries.
- Added Little Walks With God starter project profile.
- Added audit-workspace scaffold script.
