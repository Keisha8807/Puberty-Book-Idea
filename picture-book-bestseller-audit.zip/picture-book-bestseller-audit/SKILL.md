---
name: picture-book-bestseller-audit
description: "Audits board books and picture books for children roughly ages 2–8 using supplied lawful source files and, when available, dated market evidence. Produces spread maps, single-book teardowns, cross-book pattern synthesis, and originality-safe implementation briefs for the user's own books. Use when the user wants to reverse-engineer successful picture-book mechanics, compare several books, build a private pattern library, or apply evidence-based principles without copying protected expression."
---

# Picture Book Bestseller Audit

Turn selected picture books into evidence-based creative and market intelligence, then translate repeated mechanisms into original decisions for the user's own project.

## Core rule

Analyze the books; do not convert copyrighted books into a distributable knowledge replica. Store independently written analysis, page/spread references, and abstracted mechanisms—not source page images, long quotations, or reconstructed text.

## Modes

Route the request to one or more modes:

1. **Cohort Design** — select 5–12 genuinely comparable books and define the research question.
2. **Single-Book Audit** — inspect one book page by page and complete its evidence record.
3. **Comparative Audit** — audit every book independently, then compare them.
4. **Pattern Synthesis** — identify repeated mechanisms supported by at least two books.
5. **Implementation** — apply selected principles to the user's original manuscript, series, art direction, or product strategy.
6. **Pattern-Library Update** — fold completed audit records into an existing private library without adding raw copyrighted sources.

## Required inputs

Use what is already available. Ask no more than one small batch of essential questions only when unresolved:

- Which book files or page images are in scope?
- What is the target project, audience, and current development stage?
- Is the audit **book-content only** or **book content + external market evidence**?

A bestseller list or classified DOCX is a selection index, not sufficient evidence for a book-content audit. The actual book pages are needed for story and visual analysis.

## Scope and comparison gate

Classify each title before comparing it:

- **Board/toddler:** approximately ages 0–4
- **Picture book:** approximately ages 2–8
- **Early reader:** approximately ages 4–8
- **Other / out of scope**

Compare within the same format and primary job by default. Cross-format comparison is allowed only for a named mechanism such as repetition, page-turn suspense, bedtime reassurance, or concept teaching. Read `references/cohort-design.md`.

## Evidence gate

For every material claim, use one label:

- **Observed** — directly visible or readable in the supplied source
- **Inferred** — a reasoned interpretation grounded in observed evidence
- **External** — supported by a separate, dated source
- **Unavailable** — not supported by supplied materials

Never imply a feature caused bestseller status merely because it appears in a bestseller. Never invent missing pages, sales, age bands, prices, review sentiment, awards, or current availability.

Read `references/evidence-and-originality.md` before analysis.

## Vision gate

Picture-book analysis requires actual page/spread inspection.

1. Verify that the host can view rendered pages or supplied page images.
2. Inspect pages in order and preserve book boundaries.
3. If only part of a book is available, state the exact range inspected.
4. If vision is unavailable, label the result **TEXT-ONLY PARTIAL ANALYSIS** and omit unsupported conclusions about composition, palette, facial expression, visual motifs, page-turn reveals, and text–image interaction.

Read `references/picture-book-vision.md` and use `templates/spread-map.md`.

## Workflow

### Step 1 — Create the audit plan

Define:

- cohort name and research question
- format/age band
- primary category or family-life job
- target project profile
- included and excluded books
- evidence available for each title

Use `templates/audit-plan.md`. When shell access is available, `scripts/scaffold_audit.py` may create the working folders.

### Step 2 — Register sources

Create a source register using `templates/source-register.md`.

Separate:

- **Book evidence:** pages, cover, endpapers, front/back matter
- **External market evidence:** publisher, retailer, reviews, awards, bestseller lists, author platform
- **User-project evidence:** manuscript, page map, character bible, brand rules

### Step 3 — Audit each book independently

For each book, complete in this order:

1. Evidence coverage and identity
2. Page/spread map
3. Product psychology and parent/child jobs
4. Story architecture and read-aloud mechanics
5. Illustration and text–image system
6. Faith/value integration when applicable
7. Title/language and creative constraints
8. Series/worldbuilding potential
9. Evidence-based principles and originality boundaries
10. Emulate / adapt / avoid / innovate

Use `templates/single-book-audit.md` and the five-pillar framework in `references/competitive-teardown-framework.md`.

Do not synthesize while one or more selected books remain unaudited.

### Step 4 — Add market evidence separately

Only use dated external sources for current or historical claims about price, formats, sales, ranks, reviews, awards, release cadence, bundles, licensing, social presence, or community.

Record source, date, claim, and limitation in `templates/market-evidence.md`. Read `references/market-research-boundary.md`.

### Step 5 — Compare

Complete `templates/comparison-matrix.md` after all individual audits.

Compare at minimum:

- opening speed
- central desire/problem
- narrative structure
- page-turn engine
- repetition/refrain
- child participation
- emotional arc
- words-per-spread pattern
- text–image relationship
- palette and composition progression
- character system
- ending type
- parent promise
- series potential

### Step 6 — Synthesize patterns

Create a pattern only when supported by at least two comparable books. Use `templates/cross-book-patterns.md` and one `templates/pattern-card.md` for each selected pattern.

Distinguish:

- prevalence: how often it appears
- mechanism: what it does in the reading experience
- plausible effect: a supported interpretation, not proven causation
- transferability: whether it fits the user's project
- originality risk: what expression must remain distinct

### Step 7 — Build the implementation brief

Use `templates/implementation-brief.md` and `references/implementation-method.md`.

Every recommendation must include:

1. **Evidence**
2. **Pattern**
3. **Fit**
4. **Original application**
5. **Do-not-copy boundary**
6. **Test**

Prioritize recommendations with the implementation scorecard. Do not recommend a mechanism solely because it is common.

### Step 8 — Apply to the user's work

When a manuscript or page map is supplied:

- preserve the user's characters, setting, voice, theology, audience, and visual identity
- identify the exact page, spread, scene, or system affected
- show the proposed change and why it improves the reading experience
- flag tradeoffs and originality risks
- do not rewrite the entire work unless requested

Use a supplied project profile. A reusable blank profile and a Little Walks With God starter profile are in `profiles/`.

## Output structure

Use this structure unless the user requests another format:

```text
<audit-slug>/
├── 00-audit-plan.md
├── 01-source-register.md
├── 02-audit-log.md
├── books/
│   ├── 01-<book-slug>/
│   │   ├── spread-map.md
│   │   ├── single-book-audit.md
│   │   └── market-evidence.md
│   └── ...
├── synthesis/
│   ├── comparison-matrix.md
│   ├── cross-book-patterns.md
│   ├── implementation-brief.md
│   └── pattern-cards/
└── project-profile.md
```

## Completion standard

An audit is complete only when:

- evidence coverage is explicit for every book
- every selected book has an independent teardown
- visual claims come from viewed pages
- external claims have dated sources
- patterns are supported by at least two comparable books
- inference is not presented as fact
- each implementation recommendation has an originality boundary and test
- unavailable information remains marked unavailable

## Private-use and copyright boundary

Keep raw third-party book files outside the generated skill and output package. Do not distribute source images, long quotations, reconstructed text, or an analysis so exhaustive that it substitutes for the book. Extract mechanisms and independently written findings. When rights or lawful access are unclear, pause and request a lawful source or analyze only user-provided excerpts within their limits.
