# Spread Map — <Title>

## Coverage
- Source inspected:
- Edition/format:
- Pages/spreads inspected:
- Missing/unreadable material:
- Status: COMPLETE VISUAL / PARTIAL VISUAL / TEXT-ONLY PARTIAL

| Page/Spread | Text function | Story action/change | Emotional beat | Page-turn function | Composition/shot | Palette/light | Expression/body language | Visual motif | Text–image relationship | Child engagement | Evidence label |
|---|---|---|---|---|---|---|---|---|---|---|---|

## Sequence Notes
- Opening visual promise:
- Composition progression:
- Palette progression:
- Repetition and variation:
- Highest-impact page turns:
- Quietest spread and function:
- Climax spread:
- Final spread and after-feeling:
