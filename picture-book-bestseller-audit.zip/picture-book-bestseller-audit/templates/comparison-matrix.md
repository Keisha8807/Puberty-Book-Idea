# Comparison Matrix — <Cohort>

## Cohort Rule
- Research question:
- Format/age band:
- Number of books:
- Comparability limitation:

| Dimension | Book 1 | Book 2 | Book 3 | Book 4 | Book 5 | Cross-book observation |
|---|---|---|---|---|---|---|
| Opening speed | | | | | | |
| Central problem/desire | | | | | | |
| Narrative structure | | | | | | |
| Page-turn engine | | | | | | |
| Repetition/refrain | | | | | | |
| Child participation | | | | | | |
| Emotional arc | | | | | | |
| Words-per-spread pattern | | | | | | |
| Text–image relationship | | | | | | |
| Palette progression | | | | | | |
| Composition progression | | | | | | |
| Character system | | | | | | |
| Ending type | | | | | | |
| Parent promise | | | | | | |
| Faith/value integration | | | | | | |
| Series potential | | | | | | |

## Outliers
| Book | Outlier dimension | Why it matters |
|---|---|---|
