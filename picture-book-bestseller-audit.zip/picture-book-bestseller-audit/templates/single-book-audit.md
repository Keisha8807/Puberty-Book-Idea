# Single-Book Audit — <Title>

## 1. Evidence Coverage
- Source inspected:
- Pages/spreads inspected:
- Missing/unreadable material:
- Analysis status: COMPLETE VISUAL / PARTIAL VISUAL / TEXT-ONLY PARTIAL
- External market sources supplied:

## 2. Book Identity
- Title:
- Author:
- Illustrator:
- Publisher/imprint:
- Publication year and edition:
- Format/page count:
- Likely age band:
- Primary category:
- Secondary category:
- Standalone/series:

## 3. Product Psychology
- Parent problem, desire, or fantasy:
- Child need/developmental experience:
- Family-life moment supported:
- Emotional promise:
- Spiritual/value benefit, if applicable:
- Child engagement mechanisms:
- Reread hypothesis:
- Giftability hypothesis:

## 4. Story Architecture
- Opening method:
- Central desire/problem:
- Spread where introduced:
- Escalation pattern:
- Midpoint shift:
- Low point:
- Climax/peak:
- Resolution:
- Final emotional impression:
- Child role: observer / participant / hero / co-creator
- Story structure label:

## 5. Read-Aloud Mechanics
- Word count or estimate:
- Words-per-spread pattern:
- Repetition/refrain:
- Rhythm/rhyme/sound play:
- Predictability + surprise:
- Participation opportunities:
- Page-turn engine:
- Language tone:
- Title formula/value signal:

## 6. Illustration System
- Visual medium/style description:
- Character shape/proportion system:
- Character consistency:
- Composition progression:
- Camera-distance pattern:
- Palette progression:
- Facial-expression/body-language system:
- Repeated motifs:
- Highest-impact visual spreads:
- Information carried only by illustrations:
- Intentional visual constraints:

## 7. Text–Image Relationship
- Reinforces:
- Extends:
- Contradicts/creates irony:
- Leaves space for pictures:
- Page-turn reveals:

## 8. Faith/Values Integration — If Applicable
- Implicit or explicit:
- Scripture/theme/value:
- Spiritual emotion:
- Story integration:
- Family faith routine:
- Denominational/theological positioning:
- Preachiness risk and how handled:

## 9. Brand, Series, and Worldbuilding
- Instantly understandable hook:
- Recurring character/setting/theme potential:
- Repeatable story engine:
- Aesthetic identity:
- Parent persona:
- Merchandising/curriculum possibilities:
- Limits to expansion:

## 10. Competitive Advantages
- Exceptionally strong:
- Consistent:
- Distinctive:
- Hard to replicate:
- Easy to surpass:

## 11. Weaknesses and Gaps
- Unmet parent/child need:
- Emotional/spiritual gap:
- Representation gap:
- Storytelling limitation:
- Illustration/usability limitation:
- Open opportunity:

## 12. Evidence-Based Principles

### Principle 1 — <name>
- Evidence and page/spread:
- Evidence label:
- Mechanism:
- Plausible child effect:
- Plausible parent effect:
- Transferable principle:
- Originality boundary:
- Confidence: High / Medium / Low

(Repeat as needed.)

## 13. Emulate / Adapt / Avoid / Innovate
- Emulate at mechanism level:
- Adapt for the user's audience:
- Avoid:
- Innovate:

## 14. Application to the User's Project
- Story architecture:
- Read-aloud design:
- Illustration direction:
- Emotional tone:
- Faith/value integration:
- Series/worldbuilding:
- One concrete next revision:

## 15. Unavailable / External Research Needed
- Sales:
- Current pricing/formats:
- Review sentiment:
- Awards/bestseller evidence:
- Social/community:
- Other:
