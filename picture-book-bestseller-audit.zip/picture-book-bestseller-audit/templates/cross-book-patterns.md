# Cross-Book Patterns — <Cohort>

Include only patterns supported by at least two comparable books.

| Pattern | Books using it | Frequency | Strongest evidence | Mechanism | Plausible child effect | Plausible parent effect | Transferable principle | Confidence |
|---|---|---:|---|---|---|---|---|---|

## Non-Patterns and Outliers
| Observation | Why it is not yet a pattern | Additional evidence needed |
|---|---|---|

## Causation Warning
These are recurring mechanisms observed in selected books. Their presence does not prove that they caused sales, awards, or popularity.
