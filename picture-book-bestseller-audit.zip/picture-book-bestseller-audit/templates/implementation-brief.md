# Implementation Brief — <User Project>

## Project Snapshot
- Project:
- Audience:
- Format:
- Current stage:
- Core promise:
- Non-negotiable brand/faith/visual rules:

## Highest-Priority Recommendations

### Recommendation 1 — <name>
1. **Evidence:**
2. **Pattern:**
3. **Fit:**
4. **Original application:**
5. **Do-not-copy boundary:**
6. **Test:**

#### Scorecard
- Evidence strength (0–3):
- Project fit (0–3):
- Differentiation value (0–3):
- Feasibility (0–3):
- Originality safety (0–3):
- **Total /15:**
- Decision: Test now / Develop / Hold / Reject

(Repeat as needed.)

## Manuscript/Page-Map Changes
| Location | Current function | Proposed change | Pattern used | Expected reading effect | Risk/test |
|---|---|---|---|---|---|

## Illustration-System Changes
| Area | Current rule | Proposed rule | Evidence basis | Originality boundary | Test |
|---|---|---|---|---|---|

## Series/Brand Changes
| Opportunity | Why it fits | Smallest test | Do-not-copy boundary |
|---|---|---|---|

## Reject List
| Pattern considered | Why rejected |
|---|---|

## Next Revision Sprint
1. 
2. 
3. 
