# Source Register

## Book Sources
| Source ID | Book | File / location | Edition / format | Pages available | Visual access | Text access | Rights/use note | Status |
|---|---|---|---|---|---|---|---|---|

## External Market Sources
| Source ID | Book | Source / URL | Source type | Published/accessed date | Claims supported | Geographic market | Limitation |
|---|---|---|---|---|---|---|---|

## User-Project Sources
| Source ID | Document | Version/date | Purpose | Relevant sections | Status |
|---|---|---|---|---|---|

## Missing Evidence
| Book / question | Missing evidence | Effect on audit | Resolution |
|---|---|---|---|
