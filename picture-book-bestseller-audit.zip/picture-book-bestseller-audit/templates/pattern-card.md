# Pattern Card — <Pattern Name>

- Pattern ID:
- Cohort:
- Mechanism category: story / read-aloud / visual / emotional / parent job / faith-value / market / series
- Confidence: High / Medium / Low

## Evidence
| Book | Page/spread | Observed evidence | Evidence label |
|---|---|---|---|

## Mechanism
- What the pattern does:
- Conditions required:
- Failure mode:

## Effects
- Plausible child effect:
- Plausible parent effect:
- Family-life use:

## Transferability
- Best fit:
- Poor fit:
- User-project relevance:

## Originality Boundary
- Source-specific expression to avoid:
- Safe level of abstraction:

## Test
- Prototype:
- Success signal:
- Failure signal:
