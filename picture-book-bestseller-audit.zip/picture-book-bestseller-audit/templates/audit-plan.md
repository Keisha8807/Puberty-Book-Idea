# Audit Plan

## Decision to Support
- Decision:
- Why this decision matters now:
- Target project:
- Project stage:

## Research Question
- Primary question:
- Secondary questions:
- Out-of-scope questions:

## Cohort Definition
- Format/age band:
- Primary category or family-life job:
- Comparison rule:
- Planned number of books:

## Included Books
| # | Title | Format | Likely age band | Why included | Source available? | Visual coverage |
|---:|---|---|---|---|---|---|

## Excluded or Deferred Books
| Title | Reason |
|---|---|

## Evidence Plan
- Book-content evidence:
- External market evidence:
- User-project evidence:
- Known limitations:

## Deliverables
- [ ] Independent single-book audits
- [ ] Spread maps
- [ ] Market evidence records
- [ ] Comparison matrix
- [ ] Cross-book patterns
- [ ] Implementation brief
