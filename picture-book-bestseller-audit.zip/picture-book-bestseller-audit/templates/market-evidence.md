# Market Evidence — <Title>

## Coverage
- Research date:
- Geographic market:
- Edition(s):
- Limitations:

## Evidence Table
| Claim area | Finding | Evidence label | Source | Source date | Access date | Edition/market | Limitation |
|---|---|---|---|---|---|---|---|

## Review Theme Analysis
- Review sample size:
- Platforms/sources:
- Repeated delight themes:
- Repeated pain themes:
- Gifting occasions:
- Family-life use cases:
- Isolated comments not generalized:

## Market Positioning
- Publisher hook:
- Category/keywords:
- Formats/pricing:
- Awards/list appearances:
- Series/extensions:
- Seasonal strategy:
- Community/platform:

## Unavailable
- 
