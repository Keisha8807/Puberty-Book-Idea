# Competitive Teardown Framework

Use these five pillars for each book. Book-content evidence and external market evidence must remain separate.

## Pillar 1 — Product Psychology

**Question:** What does the book promise, solve, and deliver?

Extract:

- parent problem, desire, or fantasy
- child need or developmental experience
- emotional promise
- spiritual or values benefit
- family-life moment supported
- child engagement triggers
- reread and gifting hypotheses

## Pillar 2 — Story and Illustration System

**Question:** How is the book built?

Extract:

- narrative structure and emotional arc
- problem/desire introduction speed
- page-turn engine
- read-aloud mechanics
- word-count and words-per-spread pattern when measurable
- child role: observer, participant, hero, or co-creator
- visual style and character system
- palette and composition progression
- recurring motifs
- text–image reinforcement, extension, contradiction, or visual-only information
- strongest emotional spreads
- intentional creative constraints

## Pillar 3 — Brand Positioning

**Question:** What identity does the book, series, or creator reinforce?

Extract:

- category and hook
- values and emotional tone
- parent persona
- title and language patterns
- aesthetic identity
- faith positioning when applicable
- recurring character, setting, or theme system

When analyzing an author's or illustrator's catalog, do not infer a catalog pattern from one book.

## Pillar 4 — Market Strategy

**Question:** How is the book sold, distributed, extended, and kept visible?

Requires dated external evidence for:

- formats and pricing
- sales channels
- release timing and publishing cadence
- seasonal strategy
- bundles and sets
- retailer positioning
- awards and bestseller evidence
- review sentiment
- social presence and community
- licensing, merchandise, curriculum, or adaptation

## Pillar 5 — Opportunity

**Question:** What can the user's project do more clearly, differently, or better for its intended audience?

Extract:

- unmet parent or child needs
- emotional, spiritual, representation, or usability gaps
- storytelling and illustration limitations
- easy-to-surpass conventions
- hard-to-replicate strengths
- differentiation opportunities
- three things to emulate at the mechanism level
- three things to avoid
- three things to innovate
- three things to build or test next

## Mandatory closing translation

For every high-priority takeaway, provide:

- observed evidence
- mechanism
- user-project fit
- original application
- do-not-copy boundary
- test
