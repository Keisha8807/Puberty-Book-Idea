# Implementation Method

The goal is not to create a look-alike book. The goal is to improve the user's original work with evidence-based design decisions.

## Six-part recommendation

### 1. Evidence
What was observed, where, and in how many comparable books?

### 2. Pattern
What underlying mechanism is operating?

### 3. Fit
Why does the mechanism suit—or not suit—the user's audience, manuscript, brand, theology, and production constraints?

### 4. Original application
Describe a new execution using the user's own:

- characters
- relationships
- setting
- emotional question
- language and refrain
- visual motifs
- art direction
- faith/value approach

### 5. Do-not-copy boundary
Name the source-specific expression that must remain distinct.

### 6. Test
Define an observable test, for example:

- Can a child predict the refrain by the third recurrence?
- Does the central desire appear by spread 2?
- Does each page turn create a question, reveal, or emotional shift?
- Can the illustration carry information the text intentionally omits?
- Does the ending resolve the child's emotional need without overexplaining?

## Implementation scorecard

Score each proposed principle 0–3:

| Criterion | 0 | 1 | 2 | 3 |
|---|---|---|---|---|
| Evidence strength | unsupported | one weak example | two clear examples | repeated across several comparable books |
| Project fit | conflicts | limited | useful | strongly aligned |
| Differentiation value | generic | low | moderate | strengthens distinct positioning |
| Feasibility | impractical | difficult | manageable | easy within current workflow |
| Originality safety | high imitation risk | needs major change | safely adaptable | clearly distinct |

**Priority score:** total out of 15.

- 12–15: test now
- 8–11: develop or prototype
- 4–7: hold
- 0–3: reject

A high prevalence pattern can still be rejected if it conflicts with project fit or originality.
