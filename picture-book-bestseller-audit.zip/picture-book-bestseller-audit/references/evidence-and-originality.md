# Evidence and Originality Rules

## Evidence labels

### Observed
Directly visible or readable in a supplied source.

Good: “Observed: the repeated line appears on spreads 3, 5, and 7.”

### Inferred
Interpretation supported by observed details.

Good: “Inferred: the refrain likely invites child participation because it is short, repeated, and positioned before page turns.”

### External
Supported by a separate source with a date.

Good: “External: the publisher lists hardcover and board-book editions as of YYYY-MM-DD.”

### Unavailable
Not supported by supplied evidence.

Good: “Unavailable: cumulative lifetime sales.”

## Claim ledger

For high-value findings, record:

| Claim | Label | Source | Page/spread or URL | Date | Limitation |
|---|---|---|---|---|---|

## Causation boundary

Do not say:

- “This book sold because it rhymes.”
- “Parents buy it because of the palette.”
- “This feature guarantees rereads.”

Use:

- “The feature is present in X of Y books.”
- “The mechanism plausibly supports…”
- “Reviews supplied by the user repeatedly mention…”
- “This is a hypothesis to test in the user's project.”

## Quotation limits

Use only brief quotations necessary to identify a device. Prefer paraphrase and page/spread references. Do not reproduce full pages, long passages, or enough sequential text to reconstruct the book.

## Originality ladder

Move from source to application through these levels:

1. **Expression** — exact words, plot events, character design, signature composition. Do not copy.
2. **Technique** — rhyme, refrain, visual reveal, repeated motif. May be studied.
3. **Mechanism** — anticipation, participation, reassurance, escalation. May be abstracted.
4. **Principle** — design rule stated independently. May be applied.
5. **Original execution** — new character, setting, language, sequence, theology, and visual identity. Required.

## Originality check

Before recommending an application, verify:

- different central premise
- different character identities and relationships
- different setting and object system
- different scene sequence
- different wording and refrain
- different visual identity and composition solution
- no imitation of a living illustrator's distinctive style
- the recommendation fits the user's own brand rather than merely resembling the reference
