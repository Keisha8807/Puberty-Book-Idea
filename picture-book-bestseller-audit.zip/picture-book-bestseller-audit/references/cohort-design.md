# Cohort Design

A useful audit cohort is not merely a list of famous books. It is a small comparison set built around one decision.

## Recommended cohort size

- **Pilot:** 3–5 books
- **Working cohort:** 5–12 books
- **Large library:** split into sub-cohorts before synthesis

## Define one research question

Examples:

- How do bedtime picture books create emotional settling?
- How do cumulative stories create participation and page-turn momentum?
- How do gentle faith books integrate spiritual meaning without stopping the story?
- How do recurring-character picture books create a repeatable series engine?
- How do concept books teach while preserving narrative pleasure?

## Comparability filters

Include books that match most of these:

- format
- approximate reader age
- read-aloud versus independent-reading use
- emotional or developmental job
- primary category
- similar length or page architecture
- standalone versus series function

## Do not combine by default

- board books and middle-grade novels
- picture books and early readers
- bedtime reassurance and high-action adventure
- faith books and general-market books when the research question depends on theology
- books selected only because they sold well

## Cross-format exception

A cross-format cohort is allowed when the user names one narrow mechanism, such as:

- repetition
- counting
- refrain
- visual seek-and-find
- parent–child reassurance
- series branding

State that the comparison is mechanism-specific and do not generalize across all dimensions.

## Cohort quality check

Before auditing, answer:

1. What decision will this cohort help the user make?
2. What makes the titles comparable?
3. Which title is an outlier and why is it retained?
4. What evidence is available for every title?
5. What will not be claimed from this cohort?
