# External Market Research Boundary

The book itself cannot establish current market facts.

## Requires separate dated sources

- current price
- currently available formats
- retailer rank
- cumulative or recent sales
- review count and sentiment
- awards and bestseller status
- publisher marketing language
- release cadence
- seasonal promotions
- bundles and boxed sets
- social following and community
- licensing, merchandise, curriculum, or adaptations

## Source hierarchy

Prefer:

1. publisher or imprint
2. official author/illustrator site
3. award organization or bestseller-list publisher
4. major retailer listing
5. library catalog or bibliographic database
6. review corpus supplied or lawfully accessed
7. secondary article

## Research record

For every claim, record:

- exact source
- access or publication date
- whether the fact is current or historical
- geographic market when relevant
- edition/format
- limitation

## Review analysis

Do not infer parent sentiment from promotional copy. When reviews are available:

- record sample size
- distinguish verified purchaser status only when the platform supplies it
- separate repeated themes from isolated comments
- avoid treating reviews as representative of all buyers
- protect reviewer privacy and do not store unnecessary identifying information

## Bestseller language

Use precise wording:

- “Appeared on [named list] on [date]”
- “Included in the supplied all-time sales compilation”
- “Publisher reports X”

Avoid unqualified phrases such as “proven bestseller formula.”
