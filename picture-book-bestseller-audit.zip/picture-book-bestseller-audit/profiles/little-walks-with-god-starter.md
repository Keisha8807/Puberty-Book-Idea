# Little Walks With God — Starter Project Profile

Verify and update this profile before each audit.

- **Brand:** Kingdom Kids Decor
- **Universe/series:** Little Walks With God
- **Current title:** The Golden Leaf of Harvest Meadow
- **Target age:** approximately 4–7
- **Format:** illustrated 32-page children's book; read-aloud first
- **Core child experience:** wonder, sharing, care, gratitude, and gentle faith through ordinary encounters in God's creation
- **Core parent promise:** a peaceful, meaningful story that supports faith-filled connection without becoming visually or narratively heavy-handed
- **Recurring siblings:** Amara, older sister age 5; Micah, younger brother age 3
- **Age hierarchy:** Amara must read visibly older; Micah must retain toddler proportions and behavior
- **Visual identity:** premium hand-painted storybook watercolor; muted heirloom palette; warm natural light; soft washes and cold-press texture
- **Representation:** Black childhood centered with tenderness, dignity, joy, and family warmth
- **Faith integration:** gentle and story-led; direct enough to answer a child's spiritual question but not preachy; no unsupported visible Scripture text
- **World anchors:** Harvest Meadow, old oak, fence, winding path, chapel/cross, creek, patchwork blanket, lamb
- **Continuity anchors:** wagon, basket, Bible, blanket, water; ordinary leaf with no magical glow
- **Series goal:** recurring characters and locations that support multiple stories, wall art, and related resources
- **Non-negotiables:** character consistency, age hierarchy, emotional gentleness, visual cohesion, original execution
- **Current audit question:**
