# Picture Book Bestseller Audit Skill

A private, evidence-based workflow for studying board books and picture books, comparing repeated mechanisms, and applying safe abstracted principles to original work.

## Install

Place the `picture-book-bestseller-audit` folder in a skill directory supported by your host, such as:

- `~/.claude/skills/`
- `~/.copilot/skills/`
- `~/.agents/skills/`
- `.claude/skills/`
- `.github/skills/`
- `.agents/skills/`

Keep third-party book files outside this skill folder.

## Suggested first prompt

> Use the Picture Book Bestseller Audit skill. Create a pilot audit plan for these five supplied picture books. Audit each book independently with page/spread evidence, keep market claims separate, synthesize only patterns supported by at least two books, and build an originality-safe implementation brief for my supplied project profile.

## Scaffold a working audit folder

```bash
python scripts/scaffold_audit.py \
  --output ./audits \
  --cohort bedtime-models \
  --book "Book One" \
  --book "Book Two"
```

The script copies blank templates only. It does not ingest, copy, or store any book files.
