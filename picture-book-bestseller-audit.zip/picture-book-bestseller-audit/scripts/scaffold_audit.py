#!/usr/bin/env python3
"""Create a blank audit workspace from this skill's templates.

This script never copies source books. It creates only analysis templates.
"""
from __future__ import annotations

import argparse
import re
import shutil
from pathlib import Path


def slugify(value: str) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-") or "untitled"


def copy_template(src: Path, dst: Path, replacements: dict[str, str] | None = None) -> None:
    text = src.read_text(encoding="utf-8")
    for old, new in (replacements or {}).items():
        text = text.replace(old, new)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(text, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Scaffold a picture-book audit workspace.")
    parser.add_argument("--output", required=True, help="Parent output directory")
    parser.add_argument("--cohort", required=True, help="Cohort name or slug")
    parser.add_argument("--book", action="append", default=[], help="Book title; repeat for multiple books")
    parser.add_argument(
        "--profile",
        choices=["blank", "little-walks-with-god"],
        default="blank",
        help="Starter project profile",
    )
    args = parser.parse_args()

    skill_root = Path(__file__).resolve().parents[1]
    templates = skill_root / "templates"
    profiles = skill_root / "profiles"
    cohort_slug = slugify(args.cohort)
    root = Path(args.output).expanduser().resolve() / cohort_slug

    if root.exists() and any(root.iterdir()):
        raise SystemExit(f"Refusing to overwrite non-empty audit directory: {root}")

    (root / "books").mkdir(parents=True, exist_ok=True)
    (root / "synthesis" / "pattern-cards").mkdir(parents=True, exist_ok=True)

    copy_template(templates / "audit-plan.md", root / "00-audit-plan.md")
    copy_template(templates / "source-register.md", root / "01-source-register.md")
    copy_template(templates / "audit-log.md", root / "02-audit-log.md")
    copy_template(templates / "comparison-matrix.md", root / "synthesis" / "comparison-matrix.md", {"<Cohort>": args.cohort})
    copy_template(templates / "cross-book-patterns.md", root / "synthesis" / "cross-book-patterns.md", {"<Cohort>": args.cohort})
    copy_template(templates / "implementation-brief.md", root / "synthesis" / "implementation-brief.md")

    profile_src = profiles / ("little-walks-with-god-starter.md" if args.profile == "little-walks-with-god" else "blank-project-profile.md")
    shutil.copyfile(profile_src, root / "project-profile.md")

    for index, title in enumerate(args.book, start=1):
        book_dir = root / "books" / f"{index:02d}-{slugify(title)}"
        replacements = {"<Title>": title}
        copy_template(templates / "spread-map.md", book_dir / "spread-map.md", replacements)
        copy_template(templates / "single-book-audit.md", book_dir / "single-book-audit.md", replacements)
        copy_template(templates / "market-evidence.md", book_dir / "market-evidence.md", replacements)

    print(root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
