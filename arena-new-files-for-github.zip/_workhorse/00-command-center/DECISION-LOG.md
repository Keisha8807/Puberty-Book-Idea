# DECISION LOG

> Records approved changes and the reason behind them. This is not a brainstorm log. Proposed ideas remain outside this file until approved.

## DEC-2026-08-18-001 — Fresh manuscript baseline

- **Decision:** Mia's new manuscript begins from the Operation Sisterwatch cold open and current v2 bibles.
- **Reason:** Keisha does not want to revise or assemble the 2024 Canva manuscript.
- **Effect:** Old Canva pages and chapter drafts are archive/reference only. They may be mined for a topic only after explicit review; no prose, structure, design, or factual claim transfers automatically.
- **Status:** Locked

## DEC-2026-08-18-002 — Solani's age

- **Decision:** Solani Maya Washington is 11 and turns 12 in September. She is in 7th grade.
- **Reason:** Align Solani's age with Keisha's intended grade timeline.
- **Effect:** Active canon, the Episode 1 cold open, and visual prompts were updated. Retired wording—12, turning 13—must not return.
- **Status:** Locked

## DEC-2026-08-18-003 — Workhorse Foundation

- **Decision:** Build the source-of-truth and approval layer before writing n8n workflows or expanding automation.
- **Reason:** Automation must not amplify conflicting old names, drafts, assumptions, or launch plans.
- **Effect:** `_workhorse/` becomes the operating layer; existing creative files remain in place.
- **Status:** Approved for build

## DEC-2026-08-18-004 — Manual-first automation strategy

- **Decision:** Prove the Visual Factory and Episode 1 Book Factory manually before automating them in n8n.
- **Reason:** Only repeatable, useful workflows should be automated.
- **Effect:** The remaining character work and Episode 1 will serve as pilots. Every future automation must preserve human approval gates and logs.
- **Status:** Locked

## DEC-2026-08-18-005 — Workhorse scope

- **Decision:** Workhorse v1 serves Mia's Puberty Primer first. CROWN Club series development and BUFU remain parked.
- **Reason:** Finish Mia's on-ramp before opening the flagship series lane.
- **Effect:** Workers may preserve CROWN continuity and bridge clues but may not develop CROWN plots, origin, or BUFU without explicit override.
- **Status:** Locked

## DEC-2026-08-18-006 — Foundation Canon approved

- **Decision:** Keisha approved Active Canon v1.0 without correction.
- **Reason:** The compact Canon Gate accurately represents the current project and safely separates active work from archived development.
- **Effect:** The visual-production gate is unblocked. Later Workhorse workflows must read Active Canon v1.0 before beginning.
- **Status:** Locked

## DEC-2026-08-18-007 — Revised family hero decisions

- **Decision:** Mia's revised hero and Brenda's revised hero are approved. Solani's character identity is approved; her hero requires a background-only correction because the storefront used a false business name.
- **Reason:** The characters match their Lock Blocks. Solani's character should be preserved while the background is brought back into canon.
- **Effect:** Mia and Brenda art moved to approved status. Solani remains a candidate asset until the background correction is completed.
- **Status:** Locked

## DEC-2026-08-18-008 — Per-character visual libraries

- **Decision:** Every active character receives a GitHub visual-library folder with an upload inbox, candidates, approved art, reference sheets, scenes, and superseded history as needed.
- **Reason:** Keisha needs to compare Arena and external ChatGPT images directly and choose the identity she wants before additional assets are generated.
- **Effect:** Existing art is organized by character. External generated images may be uploaded as candidates and can become the approved reference after Keisha's visual gate and usage-right check.
- **Status:** Locked

## DEC-2026-08-18-009 — Mia's uploaded ChatGPT identity becomes canon

- **Decision:** Use the uploaded ChatGPT Mia hero exactly as the controlling visual identity and synchronize the text descriptions to match it.
- **Reason:** Keisha prefers this complete visual over the previous Arena hero and does not want to blend the two versions.
- **Effect:** Active Canon advances to v1.1. Mia now has high fluffy puffs with braided/cornrow fronts and star clips, small gold hoops, a multicolor paint-splash shirt, flower-pinned hot-pink overalls, matching multicolor sneakers, and colorful bracelets. Her prior hero, reference sheet, and Sisterwatch scene are superseded and preserved.
- **Supersedes:** The Mia visual portion of DEC-2026-08-18-007
- **Status:** Locked

## DEC-2026-08-18-010 — Solani's uploaded identity with preserved story locks

- **Decision:** Use the uploaded ChatGPT Solani as the controlling identity and hero outfit while retaining her gap/dimples, Uncle Mo's pencil-charm necklace, and the patchwork/mismatched-socks look.
- **Reason:** Keisha prefers the uploaded Solani but wants meaningful story details and the earlier outfit preserved rather than erased by one portrait.
- **Effect:** Active Canon advances to v1.2. Solani's hero outfit is a lavender cropped hoodie, black joggers, and purple high-tops. The pencil necklace remains a recurring story prop; patchwork jeans, striped tank, mismatched rainbow socks, and dusty sneakers become an approved alternate outfit.
- **Supersedes:** The Solani visual/background portion of DEC-2026-08-18-007
- **Status:** Locked

## DEC-2026-08-18-011 — Brenda's natural-hair mom-fashionista identity

- **Decision:** Use the revised Arena Brenda v2 as the controlling hero: uploaded joyful face direction, natural shoulder-length twist-out, terracotta wrap blouse, tailored wide-leg jeans, cognac accessories, and wooden spoon.
- **Reason:** Keisha wanted to remove the headwrap, show Brenda's natural hair, and make her read as a stylish mom fashionista distinct from Mema Hazel.
- **Effect:** Active Canon advances to v1.3. The uploaded headwrap/maxi-dress concept and prior Arena kitchen hero are superseded and preserved.
- **Supersedes:** The Brenda visual portion of DEC-2026-08-18-007
- **Status:** Locked

## DEC-2026-08-18-012 — Marcus's uploaded ChatGPT identity becomes canon

- **Decision:** Use the uploaded ChatGPT Marcus exactly as the controlling visual identity.
- **Reason:** Keisha prefers the new father design over the previous locs, glasses, and clean-shaven version.
- **Effect:** Active Canon advances to v1.4. Marcus now has a short coily tapered fade, full neat beard and mustache, no glasses, paint-splattered denim jacket, cream tee, dark jeans, blue-white-orange sneakers, and camera in hand. Earlier Marcus art is superseded and preserved.
- **Status:** Locked

## DEC-2026-08-18-013 — Mema Hazel's uploaded identity with alternate dress

- **Decision:** Use the uploaded ChatGPT Mema as the controlling identity and hero outfit while preserving the flowing floral house dress and mid-dance show-tune pose as an approved alternate.
- **Reason:** The upload strongly matches Mema's age, warmth, headwrap, cat-eye glasses, beads, joyful personality, and plant motif; Keisha wants the earlier house-dress lane retained.
- **Effect:** Active Canon advances to v1.5. Mema's hero outfit is a floral cardigan, coral top, olive pants, and pink slip-ons. Her house dress remains available for home and performance scenes.
- **Status:** Locked

## DEC-2026-08-18-014 — Uncle Mo detached from the bodega lane

- **Decision:** Uncle Mo remains Brenda's brother and a warm Washington-family member, but he is not currently associated with a bodega or other business. His larger story role will be reworked later.
- **Reason:** Keisha does not want the character visually or narratively defined by the bodega before his place in the story is reconsidered.
- **Effect:** Active Canon advances to v1.6. La Bodega de Luz remains a location concept with ownership/management pending. Existing CROWN bridge references cannot attribute the back-room access to Uncle Mo. Bodega/apron/honey-bun art becomes incompatible with current direction.
- **Status:** Locked

## DEC-2026-08-18-015 — Uncle Mo's role-neutral family hero

- **Decision:** Use the revised Arena Uncle Mo v2 as the controlling visual identity: uploaded face, short coily taper, neat beard, forest-green overshirt, cream henley, brown chinos, tan high-tops, watch, and open family-welcome gesture.
- **Reason:** The revised hero preserves the identity Keisha liked while removing every job and bodega signal.
- **Effect:** Active Canon advances to v1.7. Previous bodega/apron heroes are superseded. Uncle Mo may appear as family, but his job and larger narrative function remain intentionally unassigned.
- **Status:** Locked

## DEC-2026-08-18-016 — Seraphina's uploaded identity and DRAMA look

- **Decision:** Approve the uploaded Seraphina identity and outfit exactly, with a production-only cleanup of copyrighted/readable bedroom branding.
- **Reason:** The upload strongly matches her dramatic oldest-sister canon and Keisha approved it as-is.
- **Effect:** Seraphina's controlling hero uses the cleaned portrait crop: gold-cuffed braids, rust `DRAMA` top, distressed jeans, chain belt, platforms, phone, and original vanity/fairy-light bedroom decor.
- **Status:** Locked

## DEC-2026-08-18-017 — Lily's uploaded ChatGPT identity becomes canon

- **Decision:** Use uploaded Lily exactly as the controlling visual identity.
- **Reason:** Keisha approved the uploaded hero without changes.
- **Effect:** Lily now has beaded shoulder-length twists/braids, oversized colorful bows, rainbow tee, denim shortalls, yellow socks, pink high-tops, and hands-on-hips confidence. Her borrowed-item habit remains story canon.
- **Status:** Locked

## DEC-2026-08-18-018 — Max's uploaded ChatGPT identity becomes canon

- **Decision:** Use uploaded Max exactly as the controlling visual identity.
- **Reason:** Keisha approved the uploaded hero without changes.
- **Effect:** Active Canon advances to v1.8 for the completed family batch. Max now has a red-and-gold cape, cream `W` shirt over blue sleeves, cuffed jeans, red-blue-white sneakers, and a superhero stance. His love of filming Mia remains story canon.
- **Status:** Locked

## DEC-2026-08-18-019 — Approved school-cast batch and technical cleanup

- **Decision:** Jada and Kayla remain approved. Ms. Harmony, Ms. Armstrong, Ms. Pythagoras, Ms. Vitality, and Nurse Nightingale are approved identities.
- **Reason:** Keisha approved these characters and asked whether the visible math required repair.
- **Effect:** Production-clean heroes preserve each approved identity. Ms. Pythagoras now displays one correct theorem with unlabeled geometry; false equations, text artifacts, conflicting school branding, cropped bodies, and office labels were removed from the adult heroes.
- **Status:** Locked

## DEC-2026-08-18-020 — Dr. Smiles recast as a woman

- **Decision:** Dr. Smiles is an African American Black woman pediatrician in her early-to-mid 40s. Male art and male pronouns are retired.
- **Reason:** Keisha requested a woman Dr. Smiles.
- **Effect:** Active Canon advances to v1.9. A woman hero candidate exists, but her exact appearance remains pending visual approval.
- **Status:** Locked

## DEC-2026-08-18-021 — Emma and Sophie require redesign

- **Decision:** Do not approve or extend the current Emma and Sophie visual identities. Both characters will receive focused redesign briefs and new heroes.
- **Reason:** Keisha wants both characters redone.
- **Effect:** Current images remain candidates/superseded references only and cannot seed final reference sheets.
- **Status:** Locked

## DEC-2026-08-18-022 — Woman Dr. Smiles hero approved

- **Decision:** Approve the generated woman Dr. Smiles candidate as the controlling visual identity.
- **Reason:** Keisha approved the exact woman design after requesting the gender recast.
- **Effect:** Active Canon advances to v1.10. Dr. Smiles has short silver-accented natural tapered curls, rich medium-deep skin, a round joyful face, white coat, teal-coral-gold blouse, plum trousers, teal-white sneakers, stethoscope/icon pins, and tongue-depressor-wand/peace-sign pose. The male identity remains retired.
- **Status:** Locked

## DEC-2026-08-18-023 — Sophie's chosen identity receives cast-matched rendering

- **Decision:** Use Keisha's uploaded Sophie v03 as the exact design source and approve the premium 3D cast-matched v04 regeneration as the controlling hero.
- **Reason:** Keisha liked the v03 character but wanted her rendering to match the dimensional finish of the rest of the cast.
- **Effect:** Active Canon advances to v1.11. Sophie now has one low side-parted braid with lavender ribbon, angular lavender glasses, periwinkle cardigan, long plaid skirt, plum tights, brown Mary Janes, navy doodle notebook, and hesitant raised palm. v03 remains provenance; v04 controls production.
- **Status:** Locked

## DEC-2026-08-18-024 — Emma's earthy artist redesign approved

- **Decision:** Approve the generated earthy artist Emma redesign as the controlling visual identity.
- **Reason:** Keisha approved the redesign after rejecting Emma and Sophie's overly similar prior looks.
- **Effect:** Active Canon advances to v1.12. Emma now has half-up chunky twists with artist clips, sage square glasses, a paint-splattered denim chore jacket, mustard/sage tee, olive cargos, painted cream high-tops, pencil, paint-marked fingers, and open colorful sketchbook.
- **Status:** Locked

## DEC-2026-08-18-025 — Mia has no gap; Solani receives braces

- **Decision:** Mia has even front teeth and no gap. Solani alone retains the small front gap and now wears silver braces with changeable colorful elastics, usually lavender and teal.
- **Reason:** Keisha corrected the sisters' dental distinction and chose braces as a cute Solani signature.
- **Effect:** Active Canon advances to v1.13. Mia's first six-expression sheet is approved exactly. Any Mia reference showing a gap requires correction. Solani's no-braces model board is superseded; all future open-mouth Solani art must show braces, gap, and dimples.
- **Status:** Locked

## DEC-2026-08-18-026 — Mia reference package and Solani braces board approved

- **Decision:** Approve Mia's corrected no-gap turnaround/palette and curated remaining five expressions, completing all 11. Approve Solani's braces-aware composite model board.
- **Reason:** Keisha confirmed all three priority reference assets after Batch 2 QA.
- **Effect:** Mia's production reference package is complete: hero, turnaround, palette, all 11 expressions, immutable-trait lock, proportions, and recurring detective props. Solani's reference now locks braces/elastics, gap/dimples, expression range, both outfits, butterfly clips, pencil necklace, and palette.
- **Status:** Locked

## DEC-2026-08-18-027 — Batch 3 clean reference boards approved

- **Decision:** Approve the cleaned reference boards for Ms. Vitality, Ms. Harmony, Ms. Armstrong, Ms. Pythagoras, Nurse Nightingale, Dr. Smiles, and Kayla.
- **Reason:** Keisha rejected mismatched arrows, duplicate callouts, and annotation clutter. Clean no-arrow boards were regenerated; Kayla and Armstrong caption strips were removed without cutting portraits.
- **Effect:** Seven supporting production references are approved. Earlier annotated, captioned, branded, and false-math boards remain superseded.
- **Status:** Locked

## DEC-2026-08-18-028 — Episode 1 supporting clean references approved

- **Decision:** Approve clean reference boards for Mema Hazel, Emma, Jada, and Brenda.
- **Reason:** Keisha approved all four after their annotation-free consistency pass.
- **Effect:** Episode 1's core support cast now has approved model references. Earlier annotated and badly masked versions remain superseded. Six non-core supporting boards remain for the final consistency pass.
- **Status:** Locked

## DEC-2026-08-18-029 — Full-cast reference library complete

- **Decision:** Approve the final clean model boards for Marcus, Uncle Mo, Seraphina, Lily, Max, and Sophie.
- **Reason:** Keisha approved all six after the annotation-free consistency and Lily expression-count correction pass.
- **Effect:** All 19 active cast identities now have approved reference coverage, represented by 21 approved image assets because Mia's package uses separate turnaround and two expression sheets. The Visual Factory identity/reference milestone is complete; Episode 1 is unblocked.
- **Status:** Locked

## DEC-2026-08-18-030 — Retire bodega and BUFU; adopt Flow Grid layer

- **Decision:** Retire La Bodega de Luz and the BUFU mystery from active canon. Use Level 1 Episode Flow Cards for all 18 episodes, summarized in season Flow Grids, before detailed work packets.
- **Reason:** Keisha no longer wants the bodega/BUFU obligations and wants to see the whole narrative flow before investing in individual episode production.
- **Effect:** Active Canon advances to v1.14. Episode 17 becomes a Flow Grid rebuild slot with no bodega or BUFU. Historical files are archive-only. Planning order becomes Season 1 cards/grid → Season 2 cards/grid → cross-season audit → Minimum Viable World Bible → detailed Episode 1 packet.
- **Status:** Locked

## DEC-2026-08-19-031 — Approve Season 1 governing spine and Episode 11 payoff

- **Decision:** Approve AQ-009A as written. Mia begins Season 1 by investigating Solani across the proposed 11-episode progression, then experiences her own first period in Episode 11 and discovers that the milestone did not erase who she is.
- **Reason:** The finale is structurally load-bearing: Episode 2's individual-timing lesson, Episode 3's emotional groundwork, Episodes 5/8's privacy lesson, and Episode 9's backpack kit all pay off through Mia's own experience. Changing the ending would orphan those setups. The outline already states that Mia's timing is character-specific, not a universal reader timeline.
- **Effect:** Active Canon advances to v1.15. The Season 1 Level 1 order, governing arc, and finale endpoint are locked. Episode 8's exact privacy setup, support distribution, music clues, and Episode 17 rebuild placeholder remain sequential approval gates.
- **Approved by:** Keisha
- **Status:** Locked

## DEC-2026-08-19-032 — Approve Episode 8 accidental privacy setup with dignity locks

- **Decision:** Approve AQ-009B. Lily innocently brings Solani's red-stained pajama shorts among her “borrowed” items, and Mia applies her Episode 5 boundary lesson before the clue becomes public.
- **Reason:** The accidental discovery preserves Mia's growth instead of making her snoop again, pays off Episode 7's stinger, and turns Mia's “red means injury” myth into a concrete story clue. Replacing or re-routing the discovery would weaken those linked setups without solving a proven problem.
- **Required staging locks:** The item enters Lily's pile through a genuinely blameless household mix-up; Solani is not framed as careless; Lily is oblivious, not preparing to gossip; the stain receives no graphic, disgust, or gross-out framing; Mia intercepts the exposure; Solani controls disclosure; the resolution is private support, not a public case celebration.
- **Effect:** Active Canon advances to v1.16. The Episode 8 architecture is locked; the precise household mechanism (such as a wrong laundry basket or shared bag) must be chosen and continuity-tested in the Episode 8 Book Factory packet.
- **Approved by:** Keisha
- **Status:** Locked

## DEC-2026-08-19-033 — Approve Season 1 support web

- **Decision:** Approve AQ-009C. Brenda, Nurse Nightingale, and Solani recur as relational anchors; Ms. Harmony recurs in Episodes 3 and 5 as school social-emotional support; Mema opens the truth-telling pattern and callbacks; Coach Armstrong, Marcus, Ms. Vitality, and Dr. Smiles each appear once where their relationship or expertise naturally fits.
- **Reason:** The specialists carry story-world, representation, and trusted-pathway value that consolidation would erase. Increasing Brenda's or Solani's episode load would intensify already-identified information-dispenser/privacy risks. A community of support better earns the culturally affirming caregiver promise than one all-purpose mentor.
- **Required execution locks:** Adults provide context and care but do not solve Mia's central emotional problem; Brenda and Solani stay characters rather than lecturers; one-episode adults stay embedded in Mia's existing world; added Mema presence waits for the Ask Mema format gate.
- **Accuracy correction:** Ms. Harmony is a second-tier recurring support, not a one-off specialist.
- **Effect:** Active Canon advances to v1.17. The adult/support distribution is locked for Season 1 Level 1 planning.
- **Approved by:** Keisha
- **Status:** Locked

## DEC-2026-08-19-034 — Approve three restrained Season 1 music clues

- **Decision:** Approve AQ-009D. Keep exactly three music clues: Episode 1's muffled song fragment, Episode 3's lyric-notebook glimpse without reading, and Episode 11's private note signed with a lyric fragment.
- **Reason:** Music is an atmospheric window onto Solani's protected inner life, not a plot-active thread that needs frequent reminders. Moving the Episode 3 clue would detach it from the feelings theme or overload a later episode; reducing to two clues would make the finale payoff feel insufficiently tracked.
- **Terminology correction:** The pattern is **introduce → deepen → payoff**, not “introduce → remind → payoff.” Episode 3 deepens the meaning of Solani's music by showing that humor is not her only emotional outlet.
- **Required execution locks:** No full song, no CROWN explanation, no reading Solani's notebook, no privacy violation, and no early `Headlines` release.
- **Effect:** Active Canon advances to v1.18. The Season 1 music thread is locked at Level 1.
- **Approved by:** Keisha
- **Status:** Locked

## DEC-2026-08-19-035 — Approve Episode 17 rebuild placeholder

- **Decision:** Approve AQ-009E. Episode 17 remains **[FLOW GRID REBUILD — CROWN CLUE]** until the Season 2 Flow Grid establishes a replacement mechanism and location.
- **Reason:** Designing the replacement before the Season 2 frame exists would repeat the out-of-sequence planning problem the Flow Grid process prevents. CROWN remains valid; only its retired bodega/BUFU/Uncle Mo business-access instantiation is prohibited.
- **Constraint locked:** No La Bodega de Luz, bodega back room, BUFU, or Uncle Mo business-access mechanism may return. Placeholder approval does not approve any replacement clue, conflict, or meeting place.
- **Effect:** Active Canon advances to v1.19. All five Season 1 pre-feedback gates are complete, and the Season 1 Level 1 Flow Grid is fully approved.
- **Approved by:** Keisha
- **Status:** Locked

## DEC-2026-08-19-036 — Run Stage 2 outline feedback before Season 2 planning

- **Decision:** Approve AQ-010. Build and review the lean Season 1 Outline Feedback System packet before creating the Season 2 Flow Grid.
- **Reason:** Season 2 inherits Season 1's health framing, support roster, case rhythm, continuity threads, and handoff. Testing the fixed Season 1 architecture first creates a bounded schedule pause and avoids the larger rework cost of propagating a later finding across two seasons.
- **Sequence correction:** Feedback-first already matches Section 6's displayed unlock order. The AQ-010 alternative was inaccurately described as preserving an earlier Season 2-first order; that label is corrected and rejected.
- **Authority lock:** Reviewer findings are evidence and recommendations. They do not alter approved canon without a later Keisha decision.
- **Effect:** Active Canon advances to v1.20. Post-Season-1 work begins with the Stage 2 feedback packet; Season 2 planning waits for Keisha's review of the compiled findings.
- **Approved by:** Keisha
- **Status:** Locked

---

## DEC-2026-08-19-037 — Approve Stage 2 Outline Feedback Packet (reconciled; adults-only at Stage 2)

- **Decision:** Approve AQ-011. The `SEASON-1-STAGE-2-OUTLINE-FEEDBACK-PACKET.md` is approved as reconciled against the restored standalone **Outline Feedback System** source.
- **Reason:** The packet is a strong protocol — evidence/severity labels, independent-review-before-synthesis, no-majority-rule weighting, explicit child-privacy safeguards — and required only two fast-follow corrections rather than a rework of lanes or questions. Reconciliation confirmed: (a) the original's four adult groups map cleanly to Groups 1/3/4/5, with Group 2 (Black-girl reader and dignity lens) added intentionally as an improvement; (b) the original's numeric guardrail (ask 5–8 at first, not 50) was restored as a Review-size ceiling in Section 5; (c) the child-inclusion policy was reverted to the original rule — adults-only at Stage 2, because an outline is planning language not story prose and therefore cannot yield useful child signal, and because concentrated topic-list exposure without narrative cushioning is precisely what the “safer, more polished sample” rule protects against. Facilitation/anonymization alone solves privacy, not developmental appropriateness. Tween input moves to the later polished-sample stage where it can test voice, pacing, and tone.
- **Alternatives rejected:** Keeping optional direct tween feedback at Stage 2 (Option A) — rejected per Keisha's explicit choice to revert (Option B). Direct child reaction to outline architecture would be a reaction to the wrong artifact and would front-load exposure ahead of the original system's intent.
- **Files affected:** `01-mia-puberty-book/planning/SEASON-1-STAGE-2-OUTLINE-FEEDBACK-PACKET.md` (Section 2 provenance note rewritten; Section 5 ceiling added; Section 5 Group 2 reverted to adults-only with deferred-child-input language and clarified child-safety rule)
- **What this unlocks:** Active Canon v1.21; lean 5–8 reviewer recruitment may be planned (separate human-controlled distribution still required); synthesis under Section 10 rules; Season 2 Flow Grid remains gated until findings are reviewed
- **Authority lock:** Document approval does not authorize reviewer contact, sending, posting, child data collection, or a medical-review claim. Health review at this stage is an early risk screen only; final sourcing and qualified human review remain required at manuscript stage.
- **Approved by:** Keisha
- **Status:** Locked

---

## DEC-2026-08-20-038 — Remove Mia's first period from Season 1 and rebuild payoff (binding authorial decisions) + correct Stage 2 evidence record

- **Decision:** (1) Remove Mia's first-period event from Episode 11 and all language implying Season 1 must culminate in Mia menstruating. Mia remains 10 throughout S1; kit remains as readiness symbol, use in S1 not required; whether/when on-page period occurs to be decided separately, not auto-moved to S2. (2) Replace payoff chain `5→8→9→11` (first-period) with **Boundaries (E5) → Understanding (E8) → Preparation (E9) → Acceptance of Uncertainty (E11)**. Payoff is not "kit gets used" but Mia moving from control-through-investigation to prepared-without-certainty. (3) Rebuild E11 as emotional/relational climax: close/redefine Operation Sisterwatch, recognize Solani's privacy was never Mia's case to solve, make repair Solani controls, accept inability to predict/control timing, end on ordinary funny Mia activity, directional voice "I still didn't know when it would happen. But I knew who I could ask—and I didn't have to solve everything today." (4) Apply binding safeguards: E8 Lily oblivious, instant privatization, stain never joke, no other children see/discuss, Solani controls disclosure, Mia chooses dignity over case (not cited as validated finding). (5) Approve as internal craft rules: keep cultural particularity via lived detail (not validation), break `guesses wrong → adult explains` formula — Mia makes consequential choice every episode. (6) Health claims remain unverified; prioritize via claim sheet and actual risk level, not simulated consensus; no thresholds/treatment locked without qualified clinician. (7) Correct evidence record: Named Review Collection (fabricated personas) excluded from all counts/findings; headline replaced with "No confirmed story-level RED blocker identified during internal review. Human-reader and clinical validation remain open."; synthesis regenerated with four lanes — Verified human evidence (0), Simulated/internal diagnostic (zero weight), Authorial craft decisions, Pending validation questions.
- **Reason:** Evidence-classification error inflated simulated personas as human evidence and conflated counts into consensus. Binding story choice recenters preparedness and trust while preserving dignity and avoiding front-loaded bodily payoff at age ten. New payoff resolves Mia's core fear (control → preparedness) without requiring on-page menstruation to complete arc, per Keisha's explicit direction not to treat removal as suggesting orphaned setup.
- **Amends:** AQ-009A (first-period endpoint) in part; Flow Grid E10 stinger and E11 card/progression/rhythm/education progression; Active Canon v1.21 → v1.22; CURRENT-STATE status to provisional S2 draft only.
- **Files affected:** `01-mia-puberty-book/planning/DRAFT-SEASON-1-LEVEL-1-FLOW-GRID.md` (Season Arc closing, Table E10/E11, E11 card, Education progression, Myth repetition controls, Episode-shape, Locked AQ-009A–E section); ` _workhorse/01-rules/ACTIVE-CANON.md` (v1.22, §6 spine, E8/E11 locks); `01-mia-puberty-book/planning/STAGE-2-REVIEW-SYNTHESIS.md` (full regeneration, four lanes); `_workhorse/00-command-center/CURRENT-STATE.md` (status, writing section, bottleneck); Decision Log (this entry).
- **What this unlocks:** Season 1 approved for continued drafting/internal architecture with revised ending; Season 2 Level 1 may proceed only as provisional working draft, not validated/locked/advanced from Stage 2 gate until genuine human responses received.
- **Approved by:** Keisha (binding authorial decisions)
- **Status:** Locked
- **Supersedes (in part):** DEC-2026-08-19-031 (E11 first-period endpoint) as to timing/milestone element; prior synthesis headline/counts

---

## DEC-2026-08-20-039 — Lock: Mia does not experience first period on-page in either season

- **Decision:** Clarify and lock per Keisha's explicit direction: Mia does not get her period on-page in Season 1 **or** Season 2. The question is not left open indefinitely. Book Factory drafting for both seasons must proceed without assuming an on-page first-period scene for Mia, and without holding open placeholder flexibility for one.
- **Reason:** Keeps Episode 1 prose, kit payoff, and Season 2 Butterfly Files architecture writing against a stable ending; avoids reintroducing timeline pressure or indefinite optionality after the rebuilt Acceptance-of-Uncertainty payoff (DEC-038). Kit remains readiness symbol; Solani's period storyline remains private/dignified/centered on Solani's choices only.
- **Amends:** DEC-2026-08-20-038 as to "to be decided separately" and Active Canon v1.22 → v1.23
- **Files affected:** `_workhorse/01-rules/ACTIVE-CANON.md` (v1.23), `01-mia-puberty-book/planning/DRAFT-SEASON-1-LEVEL-1-FLOW-GRID.md` (header, Section 2 lock language), synthesis and current-state wording
- **Approved by:** Keisha
- **Status:** Locked

---

## DEC-2026-08-20-040 — Clarify: Community rec center as future CROWN home base is distinct from retired commercial business-access mechanism

- **Decision:** Per Keisha's explicit YES (distinct): the community rec center / youth sports program (public/nonprofit mentorship space, Uncle Mo mentoring + counseling-credential track) **is meaningfully different** from the retired La Bodega de Luz / BUFU / Uncle Mo business-access mechanism (commercial back-room). The E17 lock's ban is clarified to cover commercial/business-access only; the community rec center as eventual CROWN Club home base in Solani's series is **not** banned and may lean on Episode 17's eventual rebuild. E17 still requires its own packet to prove the specific replacement mechanism/location; this decision does not pre-approve any E17 design.
- **Reason:** Retired mechanism used commercial business access as the way into the club; new mechanism uses public/nonprofit mentorship space and relational access, not commercial leverage — different access logic, consistent with Uncle Mo's settled mentoring role.
- **Files affected:** `_workhorse/01-rules/ACTIVE-CANON.md` (v1.23→v1.24, E17 lock clarification), `01-mia-puberty-book/planning/DRAFT-SEASON-2-LEVEL-1-FLOW-GRID.md` (S2 header, E17 row)
- **Approved by:** Keisha
- **Status:** Locked

---

## DEC-2026-08-20-041 — Spine-first authorial override: 9-episode spine before remaining manuscript (1, 2, 5, 8, 11, 12, 13, 15, 18)

- **Decision:** Keisha elects to proceed via **9-episode spine-first drafting**: draft and polish **Episodes 1, 2, 5, 8, 11, 12, 13, 15, 18** as a text-only spine sample first — provides beginning→hinges→closes across both seasons (open, S1 hinge, dignity, S1 close, S2 open pair Hair+Bra-vo, S2 hinge, Handshake) — then draft remaining 9 episodes (3, 4, 6, 7, 9, 10, 14, 16, 17) after spine review. Overrides AQ-010 sequencing (which held all prose until Stage 2 validation). Spine reviews reclassified as Stage 3/4 on the completed spine sample via lean in-person panel (parent not of Keisha's children, clinician colleague not treating Keisha's children, teacher not currently teaching Keisha's children), 5–8 lean panel limit; independent return before synthesis.
- **Reason:** Spine sample gives reviewers a real beginning-to-end arc without requiring a full 18-episode read (which reduces follow-through), while keeping rework risk to 9 episodes rather than 18. Author consciously accepts that any systemic voice/tone/formula finding will still require revising up to 9 spine episodes — cheaper than 18 blind, but not cheap. Remaining 9 episodes benefit from validated voice.
- **Guardrails carried forward:** Text-only draft for spine sample; illustration/formatting held until after this review round. No simulated material counted as validation. Child input remains adults-only at outline sample stage; any later child input requires explicit parent/caregiver permission and private trusted-adult facilitation per packet/state rules. E9 kit execution note (conscious preparedness beat) and E17 rec-center distinction (DEC-040) remain locked.
- **Files affected:** `01-mia-puberty-book/planning/SPINE-REVIEW-SHEET.md` (new 9-episode lean sheet), `01-mia-puberty-book/planning/CROSS-SEASON-AUDIT.md` remains PASS, `_workhorse/00-command-center/CURRENT-STATE.md` bottleneck/next-action, Canon v1.24 unchanged as to spine lock.
- **Review sheet scope:** 60–75 min ask (9 × ~7 min). Validates voice/tone across seasons, arc, and delicate scene (E8); does not validate consistency across the 9 episodes not sampled (3, 4, 6, 7, 9, 10, 14, 16, 17) — flagged explicitly on the sheet so "I read the spine" ≠ "I read the book."
- **Approved by:** Keisha (binding authorial override)
- **Status:** Locked

---

## DEC-2026-08-20-042 — Backfill: Solani age correction to plain 12, 7th grade (no birthday transition)

- **Decision:** Correct Solani's age phrasing from "11; turns 12 in September" / "11→12" to plain "12, 7th grade" throughout Canon, Flow Grids, and visual locks. Birthday remains end of September (so she is already 12 for the rest of S1 and all of S2), but no transition is implied in prose or art.
- **Reason:** Age was already resolved per Keisha's review direction; the file edit was applied directly without a standalone DEC number. This backfill ensures the Decision Log remains a complete, auditable record alongside the forty-plus other logged changes — no silent edit left unlogged.
- **Files affected:** `_workhorse/01-rules/ACTIVE-CANON.md` (§4 Washington family table, §9 Solani visual lock "12, 7th grade" + Uncle Mo settled role already logged in same commit), `01-mia-puberty-book/planning/DRAFT-SEASON-2-LEVEL-1-FLOW-GRID.md` (Who S2 helps)
- **Approved by:** Keisha
- **Status:** Locked
- **Companion edits in same commit:** Uncle Mo role settled to rec center / youth sports program mentor, working toward counseling credential (also part of this age-sync commit; E17 rec-center distinction separately logged as DEC-040).

---

## DEC-2026-08-20-043 — Graphic-novel format lock; spine remains text-only

- **Decision:** Lock Mia’s Puberty Primer as a **full-color contemporary middle-grade graphic novel** with in-world visual inserts (case files, Myth Machine overlays, diagrams). Interior art is **expressive 2D digital**, animation-influenced — not Pixar-stills, not graphic memoir, not handbook-first. **3D renders** stay valid for promo, trailers, social, and character development only. Constraint Keisha named: the **9-episode spine stays text-only until human reviews.** Format lock does not start illustration, lettering, or page production.
- **Reason:** The season is already built like sequential visual storytelling; MG graphic novel is the correct shelf. 3D cast art remains useful for marketing without dictating page production.
- **Does not lock:** theme song, trailer production, GN page count, artist hire.
- **Still in force:** DEC-039 (no on-page first period); DEC-041 (spine-first, 9 episodes, lean panel).
- **Files affected:** `_workhorse/01-rules/ACTIVE-CANON.md` (v1.25), this log, CURRENT-STATE/CURRENT-SPRINT/APPROVAL-QUEUE, `01-mia-puberty-book/marketing/graphic-novel/`, `_workhorse/02-inbox/graphic-novel/`
- **What this unlocks:** Active Canon v1.25; future Book Factory packets may be written as GN *scripts* (text), not illustrated pages.
- **Approved by:** Keisha
- **Status:** Locked

---

## New decision template

```text
## DEC-YYYY-MM-DD-### — Short title

- Decision:
- Reason:
- Alternatives rejected, if relevant:
- Files/workflows affected:
- What this unlocks:
- Status: Proposed / Locked / Superseded
- Supersedes:
```
