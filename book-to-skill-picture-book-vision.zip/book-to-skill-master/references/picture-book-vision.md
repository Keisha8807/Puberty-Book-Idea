# Picture-Book Vision Module

Use this module only when `VISUAL_MODE=picture_book`.

## Purpose

Combine text extraction with actual page/spread inspection so a picture-book skill can analyze:

- visual page turns and reveal timing
- facial expression and body language
- composition, camera distance, and point of view
- palette progression and emotional color use
- character consistency across spreads
- repeated visual motifs
- text–image reinforcement, extension, contradiction, and irony
- child engagement and parent-facing emotional value

Text extraction alone cannot support these claims.

## Non-negotiable evidence rules

For every finding, label it as one of:

- **Observed** — directly visible or readable in the supplied source
- **Inferred** — a reasoned interpretation supported by observed evidence
- **External** — supplied by a separate market source, not the book itself
- **Unavailable** — cannot be determined from the supplied materials

Never convert an inference into a fact. Never fabricate missing pages, sales data, review sentiment, age bands, prices, awards, or market performance.

## Vision availability gate

Before analysis, verify that the host can inspect rendered pages or page images.

- If yes, inspect every page in sequence.
- If only selected pages are available, state the exact range inspected.
- If no vision is available, produce **TEXT-ONLY PARTIAL ANALYSIS** and omit all unsupported visual conclusions.
- OCR can recover words when text extraction fails, but OCR does not analyze pictures.

## Source handling

1. Process each book independently before cross-book comparison.
2. Preserve source filename, book title, and page order.
3. Use the printed page number when visible; otherwise use sequential PDF/image page numbers.
4. Pair facing pages as one spread when the source clearly represents a spread.
5. Note covers, endpapers, title pages, copyright pages, and back matter separately from story spreads.
6. Do not store source page images in the generated skill unless the user owns the material and explicitly requests it. Store analytical notes instead.

## Required spread map

Create `visuals/book<NN>-<slug>-spread-map.md`.

Use one row per page or spread:

| Page/Spread | Text function | Story action | Emotional beat | Page-turn function | Composition / shot | Palette / light | Character expression & body language | Visual motifs | Text–image relationship | Child engagement | Evidence status |
|---|---|---|---|---|---|---|---|---|---|---|---|

### Field guidance

- **Text function** — setup, escalation, refrain, transition, climax, resolution, reassurance, concept label, etc.
- **Story action** — what changes on this page/spread.
- **Emotional beat** — the dominant emotional movement, not just mood words.
- **Page-turn function** — question, withheld reveal, escalation, rhythm break, visual surprise, pause, or none.
- **Composition / shot** — wide, medium, close-up, overhead, low angle, centered, asymmetrical, crowded, open, etc.
- **Palette / light** — dominant colors and how they change emotional intensity.
- **Character expression & body language** — visible evidence only.
- **Visual motifs** — repeated objects, shapes, colors, settings, or symbols.
- **Text–image relationship** — repeats, clarifies, extends, contradicts, or carries information omitted by the words.
- **Child engagement** — prediction, participation, naming, counting, humor, suspense, seek-and-find, sound play, empathy, etc.

## Required single-book teardown

Create `chapters/book<NN>-<slug>.md` using this structure:

```markdown
# Book NN: <Title>

## Evidence Coverage
- Source inspected:
- Pages/spreads inspected:
- Missing or unreadable material:
- Analysis status: COMPLETE VISUAL / PARTIAL VISUAL / TEXT-ONLY PARTIAL

## Book Identity
- Author:
- Illustrator:
- Publisher / year:
- Format / page count:
- Likely age band:
- Primary and secondary category:

## Parent and Child Jobs
- Parent problem or desire served:
- Child need or developmental experience served:
- Family moment supported:
- Emotional promise:
- Reread or gifting value:

## Story Architecture
- Opening method:
- Central problem or desire:
- Escalation pattern:
- Midpoint shift:
- Climax or peak:
- Resolution:
- Final emotional impression:
- Child's role: observer / participant / hero / co-creator

## Read-Aloud Mechanics
- Repetition / refrain:
- Rhythm / rhyme / sound play:
- Predictability and surprise:
- Words per spread pattern:
- Participation opportunities:
- Page-turn engine:

## Visual System
- Character design and consistency:
- Composition progression:
- Camera-distance pattern:
- Palette progression:
- Facial-expression and body-language system:
- Repeated motifs:
- Highest-impact visual spreads:
- Information carried only by illustrations:

## Text–Image Relationship
- Where images reinforce text:
- Where images extend text:
- Where images contradict or create irony:
- Where text intentionally leaves space for pictures:

## Series and Brand Potential
- Recurring character, setting, or theme potential:
- Expandable story engine:
- Merchandising or curriculum potential:
- Limits to expansion:

## Evidence-Based Principles
For each principle, include:
1. Observed evidence
2. Mechanism
3. Likely child effect
4. Likely parent effect
5. Transferable principle
6. Originality boundary

## What to Emulate, Adapt, Avoid, and Innovate
- Emulate:
- Adapt:
- Avoid:
- Innovate:

## Application to the User's Book
- Story architecture:
- Read-aloud design:
- Illustration direction:
- Emotional tone:
- Faith/value integration, if applicable:
- Series/worldbuilding:
- One concrete next revision:

## Unavailable / Requires External Research
- Sales:
- Current pricing and formats:
- Review sentiment:
- Awards / bestseller evidence:
- Social following / community:
```

## Cross-book synthesis

Do not synthesize until every selected book has an independent teardown.

### `visuals/cross-book-patterns.md`

Include only patterns supported by at least two books.

| Pattern | Books using it | Frequency | Strongest evidence | Child effect | Parent effect | Transferable principle | Confidence |
|---|---|---:|---|---|---|---|---|

Confidence:
- **High** — directly observed across several comparable books
- **Medium** — observed in two or three books with plausible effect
- **Low** — interesting but insufficiently repeated

### `visuals/comparison-matrix.md`

Compare books on:

- opening speed
- central problem/desire
- narrative structure
- page-turn engine
- repetition/refrain
- child participation
- emotional arc
- words-per-spread pattern
- text–image relationship
- palette progression
- composition progression
- character system
- ending type
- parent promise
- series potential

### `visuals/implementation-brief.md`

Translate findings into original design rules for the user's project.

For every recommendation, use:

1. **Evidence** — what was observed across the reference books
2. **Pattern** — the underlying mechanism
3. **Fit** — why it does or does not suit the user's audience and book
4. **Original application** — a new execution using the user's own characters, setting, voice, theology, and visual identity
5. **Do-not-copy boundary** — protected expression that must remain distinct
6. **Test** — how to evaluate whether the application works

## External market research boundary

The book file cannot reliably answer current questions about:

- price and available formats
- current retailer rank
- review sentiment
- sales volume
- awards and bestseller status
- publisher marketing cadence
- social following
- bundles, licensing, or merchandise

Keep these fields marked **Unavailable** unless a separate dated source is provided. Never infer market success from story quality alone.

## Originality and copyright guardrails

- Extract mechanisms, not language or signature expression.
- Do not recreate another book's plot sequence with renamed characters.
- Do not imitate an illustrator's distinctive visual identity.
- Do not preserve long quotations or full-page text.
- Do not include source images in a distributable skill.
- Keep skills built from copyrighted third-party books private unless the stored material is limited to independently written analysis and the user has confirmed lawful use.
