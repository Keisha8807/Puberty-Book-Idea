# Output Templates

## Book Project Brief
Working title; series; brand/storyworld; canon source; target age; reading context; selected format/reason; premise; emotional promise; theme/faith truth; main character goal; fear/resistance; strength; agency; plot engine; visual promise; length target; verification needs; ecosystem role; status.

## Form Selection Report
Candidate forms; selected form; rationale; why alternatives are weaker; visual sufficiency; reading-context fit; length risk; verification flag.

## Character Performance Sheet
Story function; goal; motivation; fear/pressure; resistance/mistaken belief; strength; limitation; voice; body language; notices; avoids; relationship tenderness/friction; decision under pressure; ending change; visual continuity markers.

## Plot and Scene Map
Old normal; inciting disturbance; story question; attempts; escalation; each scene's situation/disruption/response/decision/new situation; reader emotion; page-turn purpose; climax; new normal.

## Picture-Book Spread Map
Spread; exact text; visible action; art carries; text carries; page-turn; character emotion; continuity props; silent/low-text opportunity.

## Revision Report
Structure/pacing; character/agency; POV; dialogue; read-aloud; text-picture duplication; continuity; theme/preachiness; verification needs; changes by priority; readiness.

## Canon Change Request
Proposed change; reason; level; scope; story benefit; continuity impact; existing products affected; alternatives; approval required.

## Nonfiction Research Plan
Subject/angle; age treatment; reader questions; existing coverage; authoritative sources; expert/sensitivity review; fact log/date; visual needs; accuracy/fairness review.
