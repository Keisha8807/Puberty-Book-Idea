# Dummy, Storyboard, and Illustrator Handoff

## Spread Map
Record text, action, location, emotion, page-turn purpose, visual scale, continuity props, and essential illustration notes.

## Thumbnail Dummy Test
Check repeated compositions, static scenes, weak page turns, climax space, opening/ending contrast, location clarity, and character continuity.

## Illustrator Freedom
Specify canon-critical appearance, continuity-critical props, required story action, and hidden visual information. Leave composition, gesture, secondary storytelling, environment detail, and visual humor open.

## Production Handoff
Include approved manuscript, spread map, character/location references, visual canon, prop continuity list, prohibited changes, status, and revision.
