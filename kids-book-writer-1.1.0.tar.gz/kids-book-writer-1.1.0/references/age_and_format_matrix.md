# Age and Format Matrix

Age is not enough. Match format to reading context, emotional load, visual support, and language demands.

## Ages 2–3
Caregiver read-aloud, bedtime, naming/concept, simple board-book experiences. Favor concrete language, immediate emotions, repetition, predictable patterns, sound/movement, and strong illustration support. Avoid long explanations, multi-step plots, abstract morals, and unresolved threat.

## Ages 3–5
Read-aloud, shared reading, picture books, bedtime, simple faith/concept books. Favor clear child goal/question, visual sequence, repeated structure with variation, manageable tension, and meaningful change.

## Ages 4–7
Picture-book read-aloud, shared reading, emerging independent reading. Favor richer motivation, cause/effect, scene progression, humor/tenderness/surprise, and strong payoff.

## Ages 5–8
Sophisticated picture books, beginning readers, early chapter books, devotional/educational hybrids. Favor more dialogue, layered themes, stronger agency, and controlled vocabulary when decoding matters.

## Ages 7–9+
Beginning/chapter books and educational formats. Favor episodic scenes tied to larger goals, differentiated cast, stronger internal conflict, and clear complex language.

## Context Questions
- Adult read-aloud or independent decoding?
- Bedtime, classroom, church, gift, or general reading?
- How much visual support?
- What emotional intensity is safe?
- Is frequent rereading expected?

## Length Rule
Treat word counts as project-specific ranges, not universal laws. Choose length after form, age, reading context, visual load, and story complexity are known.
