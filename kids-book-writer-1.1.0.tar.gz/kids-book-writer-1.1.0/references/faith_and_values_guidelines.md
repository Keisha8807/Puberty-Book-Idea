# Faith and Values Guidelines

Respect child dignity. Let theme operate as subtext where possible. Faith should grow from character action, emotional change, prayer, gratitude, creation, trust, or naturally relevant scripture. Avoid random verse attachment, sermon-like summaries, unrelated theology, and adult advice replacing child agency. Preserve approved Kingdom Kids faith canon when supplied.
