# Character Performance and Point of View

## Smallest Necessary Cast
Every character needs a function: protagonist, obstacle, helper, emotional mirror, comic contrast, or information source. Combine duplicates.

## Character Performance Sheet
- Name:
- Story function:
- Goal/motivation:
- Fear/pressure:
- Resistance/mistaken belief:
- Strength/limitation:
- Speech pattern:
- Body language:
- Notices:
- Avoids:
- Relationship tenderness/friction:
- Decision under pressure:
- Ending change:
- Visual continuity markers:

## Child Agency
The child should notice, choose, attempt, respond, decide, and contribute meaningfully to outcome. Adults may support without taking over.

## POV
Choose deliberately: first person, close third, omniscient, or narrator-led concept. Avoid accidental head-hopping.
