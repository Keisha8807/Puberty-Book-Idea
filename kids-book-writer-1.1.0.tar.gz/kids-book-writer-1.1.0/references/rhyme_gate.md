# Rhyme Decision Gate

Before rhyme: Does rhyme improve read-aloud? Can story logic be stated clearly in prose first? Can natural syntax and stress remain? Is vocabulary age-appropriate? Does rhyme create filler? Would prose make emotional moments stronger?

If rhyme weakens story, recommend prose.

QA: natural word order, stable stress, breath, strong rhyme words, no filler, no meaning distortion, satisfying refrain.
