# Read-Aloud Language and Figures

## Required Read-Aloud Pass
Read at normal caregiver speed. Check breath length, tongue tangles, natural stress, sentence variety, pronoun clarity without art, dialogue distinction, refrain fatigue, page-turn timing, and ending sound.

## Sound Tools
Alliteration, assonance, consonance, onomatopoeia, repetition, refrain, parallel structure.

## Rhetorical Tools
Use sparingly: repeated openings/endings, contrast, accumulation, omission, meaningful restatement, circular phrasing, immediate repetition, escalation, purposeful silence.

## Restraint Rule
A device should serve voice, emotion, rhythm, memory, page turn, or cohesion. Remove devices that mainly call attention to the writer.
