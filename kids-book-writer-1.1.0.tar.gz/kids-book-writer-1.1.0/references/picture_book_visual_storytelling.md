# Picture-Book Visual Storytelling

## Visual Possibility Gate
A picture book needs distinct visual developments. New spreads should change action, location, scale, emotion, relationship, information, or perspective.

## Text-Picture Division
Text carries voice, invisible thought, timing, irony, emotional nuance, and non-visible information. Art carries appearance, setting, visible action, expression, visual humor, and background story.

## Page Turns
Use for questions, reveals, changes, jokes, emotional pivots, uncertainty, or visual contrast.

## Silent / Low-Text Opportunities
Reduce text when an image can land emotionally, a reveal needs space, visual humor needs room, or climax is primarily visual.

## Illustration Notes
Use only for continuity-critical or hidden story information. Do not micromanage normal composition.

## Spread Map Fields
Spread number; exact text; visible action; art carries; text carries; page-turn purpose; character emotion; continuity props; silent/low-text opportunity.
