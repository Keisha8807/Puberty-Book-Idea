# Series, Catalog, and Product Ecosystem

Define each book's role: entry title, core series title, seasonal title, gift title, educator companion, activity companion, or adaptation.

For format reuse, decide whether the same core story should become a board book, picture book, beginning reader, read-aloud script, activity pack, or animation short. Adapt; do not merely trim or stretch.

When products depend on canon or approved story events, return the approved manuscript package to Storyworld Architect for ecosystem fit and canon scope.
