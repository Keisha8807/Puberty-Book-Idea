# Rights, Submissions, and Current Verification

Track print, ebook, audio, read-aloud, animation, translation, educational, merchandise, licensing, and character rights.

Verify current authoritative sources for KDP specs/policies, Etsy policies, publisher submissions, agent requirements, contract/legal norms, current market claims, education requirements, copyright/trademark/privacy/AI-disclosure rules, and platform promotion rules. Historical guidance may inform principles but is not current procedure.
