# Nonfiction, Activity, and Educational Formats

## Nonfiction
Resolve exact age, prior knowledge, subject angle, reader questions, authoritative sources, date checked, expert/sensitivity review needs, and visual explanation needs. Distinguish fact, interpretation, and speculation.

## Activity Books
State age, objective/skill, materials, instructions, differentiation, and answer-key need. Storyworld activities must use canonical objects, locations, characters, and events. Avoid random filler.

## Educator Materials
Possible outputs: discussion questions, sequencing, vocabulary, writing prompts, SEL/faith reflection, curriculum connections, and implementation notes when the book naturally supports them.
