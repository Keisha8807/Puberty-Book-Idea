# Storyworld Architect ↔ Kids Book Writer Handoff Contract

## Purpose
Keep world/canon decisions separate from manuscript craft while allowing both skills to function as one production system.

## Storyworld Architect Owns
Brand canon, umbrella canon, location canon, character identity, relationships, world logic, faith/emotional/visual canon, product-expression fit, and canon change control.

## Kids Book Writer Owns
Book form, reader context, protagonist agency, plot, scenes, POV, manuscript, rhyme/prose craft, read-aloud quality, text-picture division, spread mapping, revision, and manuscript readiness.

## Architect → Writer
Send:
1. Canon source files and revision
2. Canon status
3. Approved locked facts
4. Controlled-flex details
5. Clearly marked proposed canon
6. Core Story Brief
7. Product goal
8. Faith and emotional truth
9. Visual anchors
10. Prohibited changes

Do not force every wall-art scene into the manuscript or treat decorative art as automatic story canon.

## Writer → Architect
Return:
1. Form Selection Report
2. Book Project Brief
3. Plot and Scene Map
4. Draft/manuscript status
5. Spread Map when relevant
6. Illustration notes
7. New story facts
8. Continuity risks
9. Canon Change Requests
10. Readiness status

## Canon Change Request
- Proposed change:
- Reason:
- Level: Minor / Moderate / Major
- Scope: Product / Collection / Umbrella / Brand
- Story benefit:
- Continuity impact:
- Existing products affected:
- Alternatives that preserve canon:
- Approval required:

The Storyworld Architect approves canon consistency. Kids Book Writer approves manuscript craft readiness. Story-dependent expansion requires both.
