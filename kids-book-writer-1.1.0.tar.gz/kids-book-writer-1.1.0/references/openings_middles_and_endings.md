# Openings, Middles, and Endings

## First-Page Gate
Establish enough child voice/viewpoint, immediate situation, curiosity, desire/question, emotional tone, and visual promise to earn the page turn.

## Middle Diagnostic
Check evolution, distinct attempts, cause/effect, deepening tension/curiosity, repeated scene functions, coincidence, and continued child agency.

## Big-Scene Budget
Climax needs strongest consequence/choice, emotional focus, visual room, and earned payoff.

## Ending Audit
Central question answered/transformed; emotional payoff earned; change visible; major loose ends handled; tone matches promise; completion/hope purposeful. Series possibility should not make current story feel unfinished.
