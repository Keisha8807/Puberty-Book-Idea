# Revision and Manuscript QA

Revise in separate passes:
1. Cooling/distance
2. Structure
3. Character/agency
4. Viewpoint
5. Scene cause/effect
6. Language/dialogue
7. Read-aloud
8. Text-picture
9. Canon/continuity
10. Proof/source flags

## Readiness Status
- Needs Structural Work
- Needs Character/POV Work
- Needs Language Work
- Needs Read-Aloud Work
- Needs Canon Revision
- Illustration-Ready Manuscript
- Production-Ready Package
