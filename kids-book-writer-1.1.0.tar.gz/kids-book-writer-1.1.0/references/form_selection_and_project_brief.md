# Form Selection and Project Brief

## Candidate Forms
Narrative picture book; concept picture book; rhyming/verse; bedtime; prayer/devotional; beginning reader; chapter book; nonfiction picture book; activity/educational; mixed format.

## Selection Test
- Does the idea need sequential cause-and-effect?
- Does the child change or discover something?
- Are there enough distinct visual moments?
- Is the language heard, decoded, or both?
- Is the central pleasure story, pattern, information, prayer, or activity?
- Does the format fit canon?
- Is the length justified?

## Book Project Brief
- Working title:
- Series:
- Brand/storyworld:
- Canon source:
- Target age:
- Reading context:
- Selected form:
- Why this form:
- One-sentence premise:
- Emotional promise:
- Theme/faith truth:
- Main character goal/question:
- Fear/resistance:
- Strength:
- Agency:
- Plot engine or non-plot structure:
- Visual promise:
- Length/structure target:
- Research needs:
- Ecosystem role:
- Approval status:
