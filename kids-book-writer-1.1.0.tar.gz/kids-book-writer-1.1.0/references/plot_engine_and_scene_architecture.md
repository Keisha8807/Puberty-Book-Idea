# Plot Engine and Scene Architecture

## Narrative Plot Engine
Define Want/Question/Need; Obstacle/Resistance; Attempts; Outcomes; Escalation; Climax/Big Turn; New Normal.

## Scene Unit
1. Situation
2. Disruption
3. Response
4. Decision/action
5. New situation

Every scene should change action, information, emotion, relationship, goal, location, expectation, or visual scale.

## Internal Logic
Check cause/effect, reaction before jump, earned decisions, coincidence creating trouble rather than resolution, and meaningfully different attempts.

## Rule of Three
Use only when it strengthens escalation, comic pattern, discovery, or expectation/surprise. Do not force it.

## Climax Budget
The biggest moment needs setup, page-turn space, emotional attention, and visual room.

## Plot Test
What does the protagonist want? Why now? What resists them? What do they do? What gets harder/deeper? What choice matters most? What changes?
