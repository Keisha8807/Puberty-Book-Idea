# Source Use and Copyright Guardrails

May use general craft principles, original checklists, original examples, research methods, and public-domain archetypes independently reimagined.

Do not copy protected passages, sample manuscripts, distinctive worksheets, protected plots with superficial changes, protected characters, illustrations/layouts, or stale publisher lists presented as current.
