# Promotion, Educator, and Author Assets

Create after the core story is stable. Possible assets: one-line pitch, short/long description, book facts, audience/themes, educator guide, activity sheet, author bio, media sheet, reading-event plan, school/library/church pitch, and author-day plan. Verify changing platform/institution practices when relevant.
