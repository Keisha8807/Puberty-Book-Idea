# Kids Book Writer v1.1.0

A format-first, age-aware children's-book development engine.

## What changed
- form selection before drafting
- reader and reading-context intake
- child-agency rules
- plot and scene engine
- character performance and POV
- opening/middle/ending gates
- picture-book visual storytelling
- text-picture division
- read-aloud revision
- rhyme decision gate
- staged manuscript QA
- dummy/storyboard handoff
- nonfiction/activity/educational rules
- series/catalog planning
- current-verification and source-use guardrails
- formal handoff with KingdomKids Storyworld Architect

## Tandem Use
1. Storyworld Architect prepares canon + Core Story Brief.
2. Kids Book Writer selects form and develops manuscript.
3. Writer returns Canon Change Requests if needed.
4. Storyworld Architect reviews canon continuity.
5. Approved manuscript returns to Architect for coordinated product expansion.
